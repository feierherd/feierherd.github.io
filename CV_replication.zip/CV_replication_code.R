# Does the Monetary Cost of Abstaining Increase Turnout? Causal Evidence from Peru
# R version 4.0.4 (2021-02-15)
# Platform: x86_64-apple-darwin17.0 (64-bit)
# Running under: macOS Big Sur 10.16

# Basic setup --
rm(list=ls()) 
set.seed(1234) 
options(scipen = 999) 

# Load/install packages --
if (!require("pacman")) install.packages("pacman")
pacman::p_load(
  rdrobust,
  plyr,
  dplyr,
  scales,
  lmtest,
  xtable,
  ggplot2,
  rddensity,
  gridExtra
)

# Set your working folder --  
setwd("")

# Load data --  
load("ES_replication_file.Rdata")
load("~/Dropbox/Working_Papers/Peru_Project/Cost_of_Voting/ES_replication_file.Rdata")

# Fig. 2

plot1 <- with(dataT[dataT$mintype!="poornoex",], 
              rdplot(voted, run_poor, x.lim = c(-50,50), y.lim=c(.7,.9), 
                     y.label = "Turnout (%)", title=NULL))

p1 <- plot1$rdplot + 
  theme_minimal() +
  theme(plot.title = element_text(hjust = 0.5)) +
  labs(title="", x ="max(% Non-Poor, Poor) − max(% Poor, Extreme Poor)", y = "Turnout (%)") +
  scale_x_continuous(breaks=c(-50, -40, -30, -20, -10, 0, 10, 20, 30, 40, 50)) + 
  scale_y_continuous(labels = scales::percent_format(accuracy = 5L))

pdf("rdplot.pdf", height=4.5, width=4.5)
p1
dev.off()

# Table 3

distagg_all <- with(dataT[dataT$mintype!="poornoex",],
                    rdrobust(voted, run_poor, covs=year_2011 + year_2014 +
                               year_2016 + year_2018 + mintype_notpoor)); summary(distagg_all)

distagg_g <- with(dataT[dataT$erm==0 & dataT$mintype!="poornoex",], 
                  rdrobust(voted, run_poor, covs=year_2011 + mintype_notpoor)); summary(distagg_g) 

distagg_l <- with(dataT[dataT$erm==1 & dataT$mintype!="poornoex",], 
                  rdrobust(voted, run_poor, covs=year_2011 + mintype_notpoor)); summary(distagg_l) 

distagg_eduhi_ps <- with(dataT[dataT$mintype!="poornoex",],
                         rdrobust(votedPS1, run_poor, covs=year_2011 + year_2014 +
                                    year_2016 + year_2018  + mintype_notpoor)); summary(distagg_eduhi_ps)

distagg_edulo_ps <- with(dataT[dataT$mintype!="poornoex",],
                         rdrobust(votedPS0, run_poor, covs=year_2011 + year_2014 +
                                    year_2016 + year_2018 + mintype_notpoor)); summary(distagg_edulo_ps)

distagg_eduhi_hs <- with(dataT[dataT$mintype!="poornoex",],
                         rdrobust(votedHS1, run_poor, covs=year_2011 + year_2014 +
                                    year_2016 + year_2018  + mintype_notpoor)); summary(distagg_eduhi_hs)

distagg_edulo_hs <- with(dataT[dataT$mintype!="poornoex",],
                         rdrobust(votedHS0, run_poor, covs=year_2011 + year_2014 +
                                    year_2016 + year_2018 + mintype_notpoor)); summary(distagg_edulo_hs)

distagg_edulo_cs <- with(dataT[dataT$mintype!="poornoex",],
                         rdrobust(votedCS0, run_poor, covs=year_2011 + year_2014 +
                                    year_2016 + year_2018 + mintype_notpoor)); summary(distagg_edulo_cs)

distagg_eduhi_cs <- with(dataT[dataT$mintype!="poornoex",],
                         rdrobust(votedCS1, run_poor, covs=year_2011 + year_2014 +
                                    year_2016 + year_2018 + mintype_notpoor)); summary(distagg_eduhi_cs)

extract_rd <- function(x){
  
  out <- c(as.character(round(x$coef[1], 3)), 
           paste0("[", round (x$ci[3,1], 3), ":", round(x$ci[3,2], 3), "]"), 
           as.character(round(x$pv[3], 3)), 
           paste0(x$N_h[1], " | ", x$N_h[2]), 
           as.character(round (x$bws[1,1], 3)))
  return(out)
  
}

rd_results <- rbind(
  extract_rd(distagg_all),
  
  extract_rd(distagg_g),
  extract_rd(distagg_l),
  
  extract_rd(distagg_edulo_ps),
  extract_rd(distagg_eduhi_ps),
  
  extract_rd(distagg_edulo_hs),
  extract_rd(distagg_eduhi_hs),
  
  extract_rd(distagg_edulo_cs),
  extract_rd(distagg_eduhi_cs)
)


rd_results <- as.data.frame(rd_results)
names(rd_results) <- c("Est.", "95% CI", "p-val", "n_c | n_t", "h")

rownames(rd_results) <- c("All Elections (2010-2018)", 
                          "Regional Elections", "General Elections", 
                          "Less Than Primary","Primary or More", 
                          "Les Than High School",
                          "High School or More", 
                          "Less Than College",
                          "College or More")

xtable(rd_results, caption = "Effect of High Fine Treatment on District Turnout (two blocks no cluster)", align="lccccc")

# Fig. 3 

pdf("education.pdf", height=4, width=7)
ggplot(edulevel, aes(x=YEAR, y=VOTO, col=EDULEVEL, shape=EDULEVEL, group=EDULEVEL)) + 
  geom_point() + 
  geom_line() + 
  facet_wrap(~TIPO_ELEC) +
  scale_color_brewer(palette = "Set1", name="") + 
  ylim(0, 100) + 
  labs(x = "Año", 
       y="Turnou (%)") + theme_minimal() + theme(legend.position="bottom")
dev.off()

#############
# Appendix  #
#############

# Fig. A1

denout = rddensity(dataT$run_poor[dataT$year_2010==1], c =0)
mc = denout$test$p_jk
tit = paste("P-value density \n test: ", round(mc,2), sep='')
pdf("density.pdf", height=4.5, width=4.5)
hist(dataT$run_poor[dataT$run_poor>=-50 & dataT$run_poor<=50],breaks=40,xlab="max(% Non-Poor, Poor) − max(% Poor, Extreme Poor)", main=NULL)
abline(v=0, col='red', lwd=3)
legend('topright',tit, cex=1.1, bty='n')
dev.off()

# Table A1  

t2006 <- with(data2006T[data2006T$mintype!="poornoex",], 
              rdrobust(voted, run_poor, covs= mintype_notpoor)); summary(t2006) 

poorex <- with(data2010T[data2010T$mintype!="poornoex",], 
               rdrobust(poorex, run_poor, covs= mintype_notpoor)); summary(poorex) 

poornoex <- with(data2010T[dataT$mintype!="poornoex",], 
                 rdrobust(poornoex, run_poor, covs=  mintype_notpoor)); summary(poornoex) 

notpoor <- with(data2010T[data2010T$mintype!="poornoex",], 
                rdrobust(notpoor, run_poor, covs=  mintype_notpoor)); summary(notpoor) 


rd_results <- rbind(
  extract_rd(t2006),
  extract_rd(poorex),
  extract_rd(poornoex),
  extract_rd(notpoor))

rd_results <- as.data.frame(rd_results)
names(rd_results) <- c("Est.", "95% CI", "p-val", "n_c | n_t", "h")
rownames(rd_results) <- c("% Turnout in 2006",  "% of Extreme Poor", "% of Non-Extreme Poor", "% of Non-Poor")

xtable(rd_results, caption = "RD effect on pre-treatment covariates.", align="lccccc")

# Figure A2 

plot1 <- with(data2006T[data2006T$mintype!="poornoex",], 
              rdplot(voted, run_poor, x.lim = c(-50,50), y.lim=c(.8,1), 
                     y.label = "Turnout (%)", title="Turnout in 2006"))
p1 <- plot1$rdplot + 
  theme_minimal() +
  theme(plot.title = element_text(hjust = 0.5)) +
  labs(title="Turnout in 2006", x ="max(% Non-Poor, Poor) − max(% Poor, Extreme Poor)", y = "Turnout (%)") +
  scale_x_continuous(breaks=c(-50, -40, -30, -20, -10, 0, 10, 20, 30, 40, 50)) + 
  scale_y_continuous(labels = scales::percent_format(accuracy = 5L))

plot2 <- with(data2010T[data2010T$mintype!="poornoex",], 
              rdplot(poorex, run_poor, x.lim = c(-50,50),
                     y.label = "% of Extreme Poor", title="% of Extreme Poor"))
p2 <- plot2$rdplot + 
  theme_minimal() +
  theme(plot.title = element_text(hjust = 0.5)) +
  labs(title="% of Extreme Poor", x ="max(% Non-Poor, Poor) − max(% Poor, Extreme Poor)", y = "% of Extreme Poor") +
  scale_x_continuous(breaks=c(-50, -40, -30, -20, -10, 0, 10, 20, 30, 40, 50)) + 
  scale_y_continuous(labels = scales::percent_format(accuracy = 5L))

plot3 <- with(data2010T[data2010T$mintype!="poornoex",], 
              rdplot(poornoex, run_poor, x.lim = c(-50,50),
                     y.label = "% of Extreme Poor", title="% of Extreme Poor"))
p3 <- plot3$rdplot + 
  theme_minimal() +
  theme(plot.title = element_text(hjust = 0.5)) +
  labs(title="% of Non-Extreme Poor", x ="max(% Non-Poor, Poor) − max(% Poor, Extreme Poor)", y = "% of Non-Extreme Poor") +
  scale_x_continuous(breaks=c(-50, -40, -30, -20, -10, 0, 10, 20, 30, 40, 50)) + 
  scale_y_continuous(labels = scales::percent_format(accuracy = 5L))

plot4 <- with(data2010T[data2010T$mintype!="poornoex",], 
              rdplot(notpoor, run_poor, x.lim = c(-50,50),
                     y.label = "% of Extreme Poor", title="% of Extreme Poor"))
p4 <- plot4$rdplot + 
  theme_minimal() +
  theme(plot.title = element_text(hjust = 0.5)) +
  labs(title="% of Non-Poor", x ="max(% Non-Poor, Poor) − max(% Poor, Extreme Poor)", y = "% of Non-Poor") +
  scale_x_continuous(breaks=c(-50, -40, -30, -20, -10, 0, 10, 20, 30, 40, 50)) + 
  scale_y_continuous(labels = scales::percent_format(accuracy = 5L))

pdf("balanceplots.pdf", height=9, width=9)
grid.arrange(p1,p2,p3,p4, ncol=2)
dev.off()

# Fig. A3  

tab1 <- ddply(enaho2013,~educ,summarise,mean=mean(services_used),sd=sd(services_used), N=length(educ), median=median(services_used))
tab1
tab1$se <- tab1$sd/sqrt(tab1$N)
tab1 <- tab1[-5,]

# Manual levels
edu_table <- table(tab1$educ)
edu_levels <- names(edu_table)[c(2,4,1,3)]
tab1$edu2 <- factor(tab1$educ, levels = edu_levels)


pdf(file="State_services2.pdf", family="Times", width=5, height=4)
ggplot(tab1, aes(x = edu2, y = mean)) + 
  geom_bar(stat="identity",width=.9) +   
  theme_minimal() + 
  labs(x = "\n Education Level", y="Number of State Services Used") + 
  scale_y_continuous(limits = c(0,3))
dev.off()

# Table A2 

distagg_all <- with(dataT,
                    rdrobust(voted, run_poor, covs=year_2011 + year_2014 +
                               year_2016 + year_2018 + mintype_notpoor)); summary(distagg_all)

distagg_g <- with(dataT[dataT$erm==0,], 
                  rdrobust(voted, run_poor, covs=year_2011 + mintype_notpoor)); summary(distagg_g) 

distagg_l <- with(dataT[dataT$erm==1,], 
                  rdrobust(voted, run_poor, covs=year_2011 + mintype_notpoor)); summary(distagg_l) 

distagg_eduhi_ps <- with(dataT,
                         rdrobust(votedPS1, run_poor, covs=year_2011 + year_2014 +
                                    year_2016 + year_2018  + mintype_notpoor)); summary(distagg_eduhi_ps)

distagg_edulo_ps <- with(dataT,
                         rdrobust(votedPS0, run_poor, covs=year_2011 + year_2014 +
                                    year_2016 + year_2018 + mintype_notpoor)); summary(distagg_edulo_ps)

distagg_eduhi_hs <- with(dataT,
                         rdrobust(votedHS1, run_poor, covs=year_2011 + year_2014 +
                                    year_2016 + year_2018  + mintype_notpoor)); summary(distagg_eduhi_hs)

distagg_edulo_hs <- with(dataT,
                         rdrobust(votedHS0, run_poor, covs=year_2011 + year_2014 +
                                    year_2016 + year_2018 + mintype_notpoor)); summary(distagg_edulo_hs)

distagg_edulo_cs <- with(dataT,
                         rdrobust(votedCS0, run_poor, covs=year_2011 + year_2014 +
                                    year_2016 + year_2018 + mintype_notpoor)); summary(distagg_edulo_cs)

distagg_eduhi_cs <- with(dataT,
                         rdrobust(votedCS1, run_poor, covs=year_2011 + year_2014 +
                                    year_2016 + year_2018 + mintype_notpoor)); summary(distagg_eduhi_cs)

rd_results <- rbind(
  extract_rd(distagg_all),
  
  extract_rd(distagg_g),
  extract_rd(distagg_l),
  
  extract_rd(distagg_edulo_ps),
  extract_rd(distagg_eduhi_ps),
  
  extract_rd(distagg_edulo_hs),
  extract_rd(distagg_eduhi_hs),
  
  extract_rd(distagg_edulo_cs),
  extract_rd(distagg_eduhi_cs)
)


rd_results <- as.data.frame(rd_results)
names(rd_results) <- c("Est.", "95% CI", "p-val", "n_c | n_t", "h")

rownames(rd_results) <- c("All Elections (2010-2018)", 
                          "Regional Elections", "General Elections", 
                          "Less Than Primary","Primary or More", 
                          "Les Than High School",
                          "High School or More", 
                          "Less Than College",
                          "College or More")

xtable(rd_results, caption = "Effect of High Fine Treatment on District Turnout (two blocks no cluster)", align="lccccc")

# > sessionInfo()
# R version 4.0.4 (2021-02-15)
# Platform: x86_64-apple-darwin17.0 (64-bit)
# Running under: macOS Big Sur 10.16
# 
# Matrix products: default
# LAPACK: /Library/Frameworks/R.framework/Versions/4.0/Resources/lib/libRlapack.dylib
# 
# locale:
#   [1] en_US.UTF-8/en_US.UTF-8/en_US.UTF-8/C/en_US.UTF-8/en_US.UTF-8
# 
# attached base packages:
#   [1] stats     graphics  grDevices utils     datasets  methods   base     
# 
# other attached packages:
#   [1] gridExtra_2.3     rddensity_2.0     haven_2.3.1       fastDummies_1.6.1 sandwich_2.5-1    ggplot2_3.3.2     xtable_1.8-4     
# [8] lmtest_0.9-37     zoo_1.8-8         scales_1.1.1      dplyr_1.0.4       plyr_1.8.6        rdrobust_0.99.8   pacman_0.5.1     
# 
# loaded via a namespace (and not attached):
#   [1] Rcpp_1.0.5         RColorBrewer_1.1-2 pillar_1.4.6       compiler_4.0.4     forcats_0.5.0      tools_4.0.4        digest_0.6.25     
# [8] lifecycle_0.2.0    tibble_3.0.3       gtable_0.3.0       lattice_0.20-41    pkgconfig_2.0.3    rlang_0.4.10       DBI_1.1.0         
# [15] rstudioapi_0.11    withr_2.2.0        hms_0.5.3          generics_0.1.0     vctrs_0.3.6        grid_4.0.4         tidyselect_1.1.0  
# [22] data.table_1.13.0  glue_1.4.2         R6_2.4.1           lpdensity_2.0      readr_1.3.1        purrr_0.3.4        farver_2.0.3      
# [29] blob_1.2.1         magrittr_1.5       MASS_7.3-53        ellipsis_0.3.1     assertthat_0.2.1   colorspace_1.4-1   labeling_0.3      
# [36] stringi_1.4.6      munsell_0.5.0      crayon_1.3.4 
